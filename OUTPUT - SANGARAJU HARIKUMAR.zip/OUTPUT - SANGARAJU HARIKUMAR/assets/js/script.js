
var slider = document.getElementById("sliderVal");
var existValue = slider.value;

function resetRange() {
  document.getElementById("sliderVal").value = existValue;
}